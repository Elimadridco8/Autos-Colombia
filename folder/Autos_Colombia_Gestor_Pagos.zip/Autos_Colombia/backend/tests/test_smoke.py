import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.main import app
from app.database import Base, get_db

@pytest.fixture()
def client():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    TestingSession = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    Base.metadata.create_all(bind=engine)
    def override_db():
        db = TestingSession()
        try:
            yield db
        finally:
            db.close()
    app.dependency_overrides[get_db] = override_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()
    Base.metadata.drop_all(bind=engine)

def test_root(client):
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["app"] == "Autos Colombia"

def test_parking_entry_exit_calculates_and_frees_cell(client):
    user = client.post("/api/users", json={"full_name":"Ana Pérez","document":"CC-1001"}).json()
    vehicle = client.post("/api/vehicles", json={"plate":"ABC123","vehicle_type":"carro","owner_id":user["id"]}).json()
    cell = client.post("/api/cells", json={"code":"A-01","cell_type":"carro"}).json()
    entry = client.post("/api/parking/entry", json={"vehicle_id":vehicle["id"],"cell_id":cell["id"]})
    assert entry.status_code == 201
    assert client.get("/api/cells").json()[0]["is_occupied"] is True
    duplicate = client.post("/api/parking/entry", json={"vehicle_id":vehicle["id"]})
    assert duplicate.status_code == 409
    exit_response = client.post(f"/api/parking/{entry.json()['id']}/exit", json={})
    assert exit_response.status_code == 200
    assert exit_response.json()["amount_cop"] > 0
    assert exit_response.json()["duration_minutes"] >= 1
    assert exit_response.json()["receipt_number"].startswith("AC-")
    assert client.get("/api/cells").json()[0]["is_occupied"] is False
    assert len(client.get("/api/parking/history").json()) == 1
    assert client.post(f"/api/parking/{entry.json()['id']}/exit", json={}).status_code == 409

def test_incident_can_be_linked_to_reporting_user(client):
    user = client.post("/api/users", json={"full_name":"Luis Gómez","document":"CC-1002"}).json()
    vehicle = client.post("/api/vehicles", json={"plate":"XYZ789"}).json()
    incident = client.post("/api/incidents", json={
        "vehicle_id":vehicle["id"], "reported_by_user_id":user["id"],
        "category":"seguridad", "description":"Rayón en puerta"
    })
    assert incident.status_code == 201
    assert incident.json()["reported_by_user_id"] == user["id"]


def test_monthly_payment_create_summary_and_mark_paid(client):
    user = client.post("/api/users", json={"full_name":"María López","document":"CC-2001"}).json()
    vehicle = client.post("/api/vehicles", json={"plate":"PAY123","owner_id":user["id"]}).json()
    payload = {
        "user_id": user["id"], "vehicle_id": vehicle["id"],
        "period_start": "2026-11-01", "period_end": "2026-11-30",
        "amount_cop": 150000, "reference": "Mensualidad noviembre"
    }
    created = client.post("/api/monthly-payments", json=payload)
    assert created.status_code == 201
    assert created.json()["status"] == "pendiente"
    summary = client.get("/api/monthly-payments/summary").json()
    assert summary["total_facturado_cop"] == 150000
    assert summary["valor_pendiente_cop"] == 150000
    paid = client.patch(f"/api/monthly-payments/{created.json()['id']}/pay", json={})
    assert paid.status_code == 200
    assert paid.json()["status"] == "pagado"
    assert paid.json()["paid_at"] is not None
    summary = client.get("/api/monthly-payments/summary").json()
    assert summary["valor_recaudado_cop"] == 150000
    assert summary["valor_pendiente_cop"] == 0


def test_monthly_payment_rejects_invalid_or_overlapping_period(client):
    user = client.post("/api/users", json={"full_name":"Carlos Ruiz","document":"CC-2002"}).json()
    vehicle = client.post("/api/vehicles", json={"plate":"PAY456","owner_id":user["id"]}).json()
    payload = {
        "user_id": user["id"], "vehicle_id": vehicle["id"],
        "period_start": "2026-11-01", "period_end": "2026-11-30",
        "amount_cop": 120000
    }
    assert client.post("/api/monthly-payments", json=payload).status_code == 201
    overlapping = {**payload, "period_start": "2026-11-15", "period_end": "2026-12-15"}
    assert client.post("/api/monthly-payments", json=overlapping).status_code == 409
    invalid = {**payload, "period_start": "2026-12-01", "period_end": "2026-11-30"}
    assert client.post("/api/monthly-payments", json=invalid).status_code == 422


def test_monthly_payment_rejects_unknown_user_or_vehicle(client):
    payload = {
        "user_id": 999, "vehicle_id": 999,
        "period_start": "2026-12-01", "period_end": "2026-12-31",
        "amount_cop": 100000
    }
    assert client.post("/api/monthly-payments", json=payload).status_code == 404


def test_monthly_payment_cannot_be_created_as_paid(client):
    user = client.post("/api/users", json={"full_name":"Diana Mesa","document":"CC-2003"}).json()
    vehicle = client.post("/api/vehicles", json={"plate":"PAY789","owner_id":user["id"]}).json()
    response = client.post("/api/monthly-payments", json={
        "user_id": user["id"], "vehicle_id": vehicle["id"],
        "period_start": "2026-12-01", "period_end": "2026-12-31",
        "amount_cop": 100000, "status": "pagado"
    })
    assert response.status_code == 422
