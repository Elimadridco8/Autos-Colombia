import os
from datetime import datetime, timezone
from math import ceil
from uuid import uuid4
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from .database import Base, engine, get_db
from . import models, schemas, crud

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Autos Colombia API", version="2.0.0",
              description="Gestión de usuarios, vehículos, parqueo, novedades y mensualidades.")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:4200", "http://127.0.0.1:4200"],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

HOURLY_RATE_COP = int(os.getenv("HOURLY_RATE_COP", "3000"))

@app.get("/")
def root():
    return {"app": "Autos Colombia", "docs": "/docs", "status": "ok", "tarifa_hora_cop": HOURLY_RATE_COP}

def simple_routes(path, model, input_schema, output_schema):
    @app.get(f"/api/{path}", response_model=list[output_schema], tags=[path])
    def list_items(db: Session = Depends(get_db)):
        return crud.list_all(db, model)
    @app.post(f"/api/{path}", response_model=output_schema, status_code=201, tags=[path])
    def create_item(data: input_schema, db: Session = Depends(get_db)):
        return crud.create_simple(db, model, data)
    @app.patch(f"/api/{path}/{{item_id}}", response_model=output_schema, tags=[path])
    def update_item(item_id: int, data: dict, db: Session = Depends(get_db)):
        return crud.patch_simple(db, model, item_id, data)
    @app.delete(f"/api/{path}/{{item_id}}", tags=[path])
    def remove_item(item_id: int, db: Session = Depends(get_db)):
        return crud.delete_simple(db, model, item_id)

simple_routes("users", models.User, schemas.UserIn, schemas.UserOut)
simple_routes("cells", models.Cell, schemas.CellIn, schemas.CellOut)
simple_routes("vehicles", models.Vehicle, schemas.VehicleIn, schemas.VehicleOut)
simple_routes("incidents", models.Incident, schemas.IncidentIn, schemas.IncidentOut)

@app.get("/api/monthly-payments/summary", tags=["monthly-payments"])
def monthly_payments_summary(db: Session = Depends(get_db)):
    rows = db.query(
        models.MonthlyPayment.status,
        func.count(models.MonthlyPayment.id),
        func.coalesce(func.sum(models.MonthlyPayment.amount_cop), 0)
    ).group_by(models.MonthlyPayment.status).all()
    summary = {
        "total_registros": 0, "total_facturado_cop": 0,
        "pendientes": 0, "valor_pendiente_cop": 0,
        "pagados": 0, "valor_recaudado_cop": 0
    }
    for status, count, amount in rows:
        summary["total_registros"] += count
        summary["total_facturado_cop"] += int(amount or 0)
        if status == "pagado":
            summary["pagados"] = count
            summary["valor_recaudado_cop"] = int(amount or 0)
        else:
            summary["pendientes"] += count
            summary["valor_pendiente_cop"] += int(amount or 0)
    return summary

@app.get("/api/monthly-payments", response_model=list[schemas.MonthlyPaymentOut], tags=["monthly-payments"])
def list_monthly_payments(db: Session = Depends(get_db)):
    return crud.list_all(db, models.MonthlyPayment)

@app.post("/api/monthly-payments", response_model=schemas.MonthlyPaymentOut, status_code=201, tags=["monthly-payments"])
def create_monthly_payment(data: schemas.MonthlyPaymentIn, db: Session = Depends(get_db)):
    if data.status != "pendiente":
        raise HTTPException(422, "Los pagos nuevos deben registrarse como pendientes; use la acción de registrar pago")
    user = db.get(models.User, data.user_id)
    vehicle = db.get(models.Vehicle, data.vehicle_id)
    if not user:
        raise HTTPException(404, "Usuario no encontrado")
    if not user.active:
        raise HTTPException(409, "No se puede facturar a un usuario inactivo")
    if not vehicle:
        raise HTTPException(404, "Vehículo no encontrado")
    overlap = db.scalar(select(models.MonthlyPayment).where(
        models.MonthlyPayment.vehicle_id == data.vehicle_id,
        models.MonthlyPayment.period_start <= data.period_end,
        models.MonthlyPayment.period_end >= data.period_start
    ))
    if overlap:
        raise HTTPException(409, "Ya existe una mensualidad para ese vehículo en un periodo que se cruza con las fechas indicadas")
    return crud.create_simple(db, models.MonthlyPayment, data)


@app.get("/api/parking/active", response_model=list[schemas.SessionOut], tags=["parking"])
def active_sessions(db: Session = Depends(get_db)):
    return db.scalars(select(models.ParkingSession).where(models.ParkingSession.exit_at.is_(None)).order_by(models.ParkingSession.entry_at.desc())).all()

@app.get("/api/parking/history", response_model=list[schemas.SessionOut], tags=["parking"])
def parking_history(db: Session = Depends(get_db)):
    return db.scalars(select(models.ParkingSession).order_by(models.ParkingSession.entry_at.desc())).all()

@app.post("/api/parking/entry", response_model=schemas.SessionOut, status_code=201, tags=["parking"])
def register_entry(data: schemas.EntryIn, db: Session = Depends(get_db)):
    vehicle = db.get(models.Vehicle, data.vehicle_id)
    if not vehicle:
        raise HTTPException(404, "Vehículo no encontrado")
    if vehicle.owner_id and not db.get(models.User, vehicle.owner_id):
        raise HTTPException(422, "El propietario asociado no existe")
    existing = db.scalar(select(models.ParkingSession).where(models.ParkingSession.vehicle_id == data.vehicle_id, models.ParkingSession.exit_at.is_(None)))
    if existing:
        raise HTTPException(409, "El vehículo ya tiene una sesión activa")
    if data.cell_id is not None:
        cell = db.get(models.Cell, data.cell_id)
        if not cell or not cell.is_active:
            raise HTTPException(404, "Celda no encontrada o inactiva")
        if cell.is_occupied:
            raise HTTPException(409, "La celda está ocupada")
    else:
        cell = db.scalar(select(models.Cell).where(models.Cell.is_active.is_(True), models.Cell.is_occupied.is_(False)).order_by(models.Cell.id))
        if not cell:
            raise HTTPException(409, "No hay celdas disponibles")
    cell.is_occupied = True
    session = models.ParkingSession(vehicle_id=data.vehicle_id, cell_id=cell.id, entry_notes=data.entry_notes)
    db.add(session)
    try:
        db.commit()
        db.refresh(session)
    except Exception:
        db.rollback()
        raise HTTPException(409, "No se pudo registrar la entrada; valide la disponibilidad de la celda")
    return session

@app.post("/api/parking/{session_id}/exit", response_model=schemas.SessionOut, tags=["parking"])
def register_exit(session_id: int, data: schemas.ExitIn, db: Session = Depends(get_db)):
    session = db.get(models.ParkingSession, session_id)
    if not session:
        raise HTTPException(404, "Sesión de parqueo no encontrada")
    if session.exit_at:
        raise HTTPException(409, "La salida ya fue registrada")
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    entry = session.entry_at.replace(tzinfo=None)
    minutes = max(1, ceil((now - entry).total_seconds() / 60))
    billable_hours = max(1, ceil(minutes / 60))
    session.exit_at = now
    session.duration_minutes = minutes
    session.amount_cop = billable_hours * HOURLY_RATE_COP
    session.receipt_number = f"AC-{now:%Y%m%d}-{uuid4().hex[:8].upper()}"
    session.exit_notes = data.exit_notes
    session.cell.is_occupied = False
    db.commit()
    db.refresh(session)
    return session

@app.patch("/api/monthly-payments/{payment_id}/pay", response_model=schemas.MonthlyPaymentOut, tags=["monthly-payments"])
def mark_payment_paid(payment_id: int, db: Session = Depends(get_db)):
    payment = db.get(models.MonthlyPayment, payment_id)
    if not payment:
        raise HTTPException(404, "Mensualidad no encontrada")
    if payment.status == "pagado":
        raise HTTPException(409, "La mensualidad ya está pagada")
    payment.status = "pagado"
    payment.paid_at = datetime.now(timezone.utc).replace(tzinfo=None)
    db.commit()
    db.refresh(payment)
    return payment
