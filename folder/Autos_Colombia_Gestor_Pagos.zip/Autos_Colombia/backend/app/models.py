from datetime import datetime, date, timezone
from sqlalchemy import String, Integer, DateTime, Date, ForeignKey, Boolean, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    full_name: Mapped[str] = mapped_column(String(120), nullable=False)
    document: Mapped[str] = mapped_column(String(40), unique=True, index=True, nullable=False)
    phone: Mapped[str | None] = mapped_column(String(30))
    email: Mapped[str | None] = mapped_column(String(120))
    role: Mapped[str] = mapped_column(String(30), default="cliente")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    vehicles = relationship("Vehicle", back_populates="owner")

class Cell(Base):
    __tablename__ = "cells"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    code: Mapped[str] = mapped_column(String(20), unique=True, index=True)
    cell_type: Mapped[str] = mapped_column(String(30), default="carro")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_occupied: Mapped[bool] = mapped_column(Boolean, default=False)
    sessions = relationship("ParkingSession", back_populates="cell")

class Vehicle(Base):
    __tablename__ = "vehicles"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    plate: Mapped[str] = mapped_column(String(12), unique=True, index=True)
    vehicle_type: Mapped[str] = mapped_column(String(30), default="carro")
    brand: Mapped[str | None] = mapped_column(String(50))
    color: Mapped[str | None] = mapped_column(String(30))
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    owner = relationship("User", back_populates="vehicles")
    sessions = relationship("ParkingSession", back_populates="vehicle")
    incidents = relationship("Incident", back_populates="vehicle")

class ParkingSession(Base):
    __tablename__ = "parking_sessions"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    vehicle_id: Mapped[int] = mapped_column(ForeignKey("vehicles.id"), nullable=False)
    cell_id: Mapped[int] = mapped_column(ForeignKey("cells.id"), nullable=False)
    entry_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc).replace(tzinfo=None))
    exit_at: Mapped[datetime | None] = mapped_column(DateTime)
    entry_notes: Mapped[str | None] = mapped_column(Text)
    exit_notes: Mapped[str | None] = mapped_column(Text)
    duration_minutes: Mapped[int | None] = mapped_column(Integer)
    amount_cop: Mapped[int | None] = mapped_column(Integer)
    receipt_number: Mapped[str | None] = mapped_column(String(40), unique=True)
    vehicle = relationship("Vehicle", back_populates="sessions")
    cell = relationship("Cell", back_populates="sessions")

class Incident(Base):
    __tablename__ = "incidents"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    vehicle_id: Mapped[int] = mapped_column(ForeignKey("vehicles.id"), nullable=False)
    reported_by_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc).replace(tzinfo=None))
    category: Mapped[str] = mapped_column(String(50))
    description: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(30), default="abierta")
    vehicle = relationship("Vehicle", back_populates="incidents")
    reported_by = relationship("User")

class MonthlyPayment(Base):
    __tablename__ = "monthly_payments"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    vehicle_id: Mapped[int] = mapped_column(ForeignKey("vehicles.id"), nullable=False)
    period_start: Mapped[date] = mapped_column(Date)
    period_end: Mapped[date] = mapped_column(Date)
    amount_cop: Mapped[int] = mapped_column(Integer)
    paid_at: Mapped[datetime | None] = mapped_column(DateTime)
    status: Mapped[str] = mapped_column(String(20), default="pendiente")
    reference: Mapped[str | None] = mapped_column(String(80))
    user = relationship("User")
    vehicle = relationship("Vehicle")
