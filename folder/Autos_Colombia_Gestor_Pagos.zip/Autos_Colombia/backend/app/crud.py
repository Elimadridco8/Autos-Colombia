from datetime import datetime
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

def list_all(db: Session, model):
    return db.scalars(select(model).order_by(model.id.desc())).all()

def get_or_404(db: Session, model, item_id: int):
    obj = db.get(model, item_id)
    if obj is None:
        raise HTTPException(404, f"{model.__name__} no encontrado")
    return obj

def create_simple(db: Session, model, data):
    obj = model(**data.model_dump())
    db.add(obj)
    try:
        db.commit()
        db.refresh(obj)
    except Exception:
        db.rollback()
        raise HTTPException(409, "No se pudo guardar. Verifique duplicados y referencias.")
    return obj

def patch_simple(db: Session, model, item_id: int, data: dict):
    obj = get_or_404(db, model, item_id)
    allowed = {column.name for column in model.__table__.columns if column.name != "id"}
    for key, value in data.items():
        if key in allowed:
            setattr(obj, key, value)
    try:
        db.commit()
        db.refresh(obj)
    except Exception:
        db.rollback()
        raise HTTPException(409, "No se pudo actualizar; revise referencias o restricciones.")
    return obj

def delete_simple(db: Session, model, item_id: int):
    obj = get_or_404(db, model, item_id)
    db.delete(obj)
    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(409, "No se puede eliminar porque tiene registros relacionados.")
    return {"message": "Registro eliminado"}
