from datetime import datetime, date
from pydantic import BaseModel, ConfigDict, Field, model_validator

class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)

class UserIn(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    document: str = Field(min_length=3, max_length=40)
    phone: str | None = None
    email: str | None = None
    role: str = "cliente"
    active: bool = True
class UserOut(UserIn, ORMModel):
    id: int

class CellIn(BaseModel):
    code: str = Field(min_length=1, max_length=20)
    cell_type: str = "carro"
    is_active: bool = True
class CellOut(CellIn, ORMModel):
    id: int
    is_occupied: bool

class VehicleIn(BaseModel):
    plate: str = Field(min_length=5, max_length=12)
    vehicle_type: str = "carro"
    brand: str | None = None
    color: str | None = None
    owner_id: int | None = None
class VehicleOut(VehicleIn, ORMModel):
    id: int

class EntryIn(BaseModel):
    vehicle_id: int
    cell_id: int | None = None
    entry_notes: str | None = None
class ExitIn(BaseModel):
    exit_notes: str | None = None
class SessionOut(ORMModel):
    id: int
    vehicle_id: int
    cell_id: int
    entry_at: datetime
    exit_at: datetime | None
    entry_notes: str | None
    exit_notes: str | None
    duration_minutes: int | None = None
    amount_cop: int | None
    receipt_number: str | None = None

class IncidentIn(BaseModel):
    vehicle_id: int
    reported_by_user_id: int | None = None
    category: str = Field(min_length=2, max_length=50)
    description: str = Field(min_length=3)
    status: str = "abierta"
class IncidentOut(IncidentIn, ORMModel):
    id: int
    created_at: datetime

class MonthlyPaymentIn(BaseModel):
    user_id: int
    vehicle_id: int
    period_start: date
    period_end: date
    amount_cop: int = Field(gt=0)
    status: str = "pendiente"
    reference: str | None = Field(default=None, max_length=80)
    @model_validator(mode="after")
    def valid_period(self):
        if self.period_end < self.period_start:
            raise ValueError("La fecha final debe ser igual o posterior a la inicial")
        if self.reference is not None:
            self.reference = self.reference.strip() or None
        return self
class MonthlyPaymentOut(MonthlyPaymentIn, ORMModel):
    id: int
    paid_at: datetime | None
