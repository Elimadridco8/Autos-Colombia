import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from './api.service';
import { User, Cell, Vehicle, ParkingSession, Incident, MonthlyPayment, PaymentSummary } from './models';

type Section = 'dashboard'|'vehicles'|'users'|'cells'|'parking'|'incidents'|'payments';
@Component({
 selector: 'app-root', standalone: true, imports: [CommonModule, FormsModule],
 templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  api = inject(ApiService);
  section: Section = 'dashboard';
  message = ''; error = '';
  users: User[]=[]; cells: Cell[]=[]; vehicles: Vehicle[]=[]; sessions: ParkingSession[]=[]; incidents: Incident[]=[]; payments: MonthlyPayment[]=[];
  paymentSummary: PaymentSummary = {total_registros:0,total_facturado_cop:0,pendientes:0,valor_pendiente_cop:0,pagados:0,valor_recaudado_cop:0};
  paymentStatusFilter = 'todos'; paymentSearch = '';
  userForm: User = {full_name:'',document:'',phone:'',email:'',role:'cliente'};
  cellForm: Cell = {code:'',cell_type:'carro',is_active:true};
  vehicleForm: Vehicle = {plate:'',vehicle_type:'carro',brand:'',color:'',owner_id:null};
  entryForm = {vehicle_id: 0, cell_id: undefined as number|undefined, entry_notes:''};
  
  incidentForm: Incident = {vehicle_id:0,category:'novedad',description:'',status:'abierta'};
  paymentForm: MonthlyPayment = {user_id:0,vehicle_id:0,period_start:'',period_end:'',amount_cop:0,status:'pendiente',reference:''};
  ngOnInit(): void { this.refresh(); }
  navigate(s: Section): void { this.section=s; this.message=''; this.error=''; }
  refresh(): void {
    this.api.users().subscribe({next:v=>this.users=v,error:e=>this.fail(e)});
    this.api.cells().subscribe({next:v=>this.cells=v,error:e=>this.fail(e)});
    this.api.vehicles().subscribe({next:v=>this.vehicles=v,error:e=>this.fail(e)});
    this.api.activeSessions().subscribe({next:v=>this.sessions=v,error:e=>this.fail(e)});
    this.api.incidents().subscribe({next:v=>this.incidents=v,error:e=>this.fail(e)});
    this.api.payments().subscribe({next:v=>this.payments=v,error:e=>this.fail(e)});
    this.api.paymentSummary().subscribe({next:v=>this.paymentSummary=v,error:e=>this.fail(e)});
  }
  private fail(e: any): void { this.error=e?.error?.detail || 'No fue posible conectar con la API. Verifique que FastAPI esté activo.'; }
  private done(msg: string): void { this.message=msg; this.error=''; this.refresh(); }
  saveUser(): void { this.api.addUser(this.userForm).subscribe({next:()=>{this.userForm={full_name:'',document:'',phone:'',email:'',role:'cliente'};this.done('Usuario registrado.');},error:e=>this.fail(e)}); }
  saveCell(): void { this.api.addCell(this.cellForm).subscribe({next:()=>{this.cellForm={code:'',cell_type:'carro',is_active:true};this.done('Celda registrada.');},error:e=>this.fail(e)}); }
  saveVehicle(): void { this.api.addVehicle(this.vehicleForm).subscribe({next:()=>{this.vehicleForm={plate:'',vehicle_type:'carro',brand:'',color:'',owner_id:null};this.done('Vehículo registrado.');},error:e=>this.fail(e)}); }
  entry(): void { this.api.entry(this.entryForm).subscribe({next:()=>{this.entryForm={vehicle_id:0,cell_id:undefined,entry_notes:''};this.done('Entrada registrada y celda asignada.');},error:e=>this.fail(e)}); }
  exit(s: ParkingSession): void { this.api.exit(s.id).subscribe({next:r=>{this.message=`Salida registrada. Tiempo: ${r.duration_minutes} minutos. Total: ${new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',maximumFractionDigits:0}).format(r.amount_cop || 0)}. Comprobante: ${r.receipt_number}.`;this.error='';this.refresh();},error:e=>this.fail(e)}); }
  saveIncident(): void { this.api.addIncident(this.incidentForm).subscribe({next:()=>{this.incidentForm={vehicle_id:0,category:'novedad',description:'',status:'abierta'};this.done('Novedad registrada.');},error:e=>this.fail(e)}); }
  savePayment(): void { this.api.addPayment(this.paymentForm).subscribe({next:()=>{this.paymentForm={user_id:0,vehicle_id:0,period_start:'',period_end:'',amount_cop:0,status:'pendiente',reference:''};this.done('Mensualidad registrada.');},error:e=>this.fail(e)}); }
  markPaid(p: MonthlyPayment): void {
    if (!p.id || p.status === 'pagado') return;
    if (!confirm(`¿Confirmar el pago de ${this.money(p.amount_cop)} para ${this.plate(p.vehicle_id)}?`)) return;
    this.api.markPaid(p.id).subscribe({next:()=>this.done('Pago registrado correctamente.'),error:e=>this.fail(e)});
  }
  filteredPayments(): MonthlyPayment[] {
    const term = this.paymentSearch.trim().toLowerCase();
    return this.payments.filter(p => {
      const statusOk = this.paymentStatusFilter === 'todos' || p.status === this.paymentStatusFilter;
      const text = `${this.userName(p.user_id)} ${this.plate(p.vehicle_id)} ${p.reference || ''}`.toLowerCase();
      return statusOk && (!term || text.includes(term));
    });
  }
  money(value: number): string {
    return new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',maximumFractionDigits:0}).format(value || 0);
  }
  isOverdue(p: MonthlyPayment): boolean {
    return p.status !== 'pagado' && new Date(`${p.period_end}T23:59:59`) < new Date();
  }
  plate(id: number): string { return this.vehicles.find(v=>v.id===id)?.plate ?? `Vehículo #${id}`; }
  userName(id: number): string { return this.users.find(v=>v.id===id)?.full_name ?? `Usuario #${id}`; }
  cellCode(id: number): string { return this.cells.find(c=>c.id===id)?.code ?? `Celda #${id}`; }
  freeCells(): number { return this.cells.filter(c=>c.is_active && !c.is_occupied).length; }
  openIncidents(): number { return this.incidents.filter(i=>i.status==='abierta').length; }
  nav: {id: Section; label: string}[] = [
    {id:'dashboard',label:'▦  Resumen'}, {id:'vehicles',label:'🚘  Vehículos'},
    {id:'parking',label:'↔  Entradas y salidas'}, {id:'cells',label:'▤  Celdas'},
    {id:'users',label:'♙  Usuarios'}, {id:'incidents',label:'⚑  Novedades'},
    {id:'payments',label:'＄  Mensualidades'}
  ];
  title(): string {
    const titles: Record<Section,string> = {dashboard:'Resumen general',vehicles:'Gestión de vehículos',users:'Gestión de usuarios',cells:'Celdas de parqueo',parking:'Entradas y salidas',incidents:'Novedades e incidentes',payments:'Mensualidades'};
    return titles[this.section];
  }
}
