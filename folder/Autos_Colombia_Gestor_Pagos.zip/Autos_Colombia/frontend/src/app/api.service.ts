import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User, Cell, Vehicle, ParkingSession, Incident, MonthlyPayment, PaymentSummary } from './models';
@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private base = 'http://127.0.0.1:8000/api';
  users(): Observable<User[]> { return this.http.get<User[]>(`${this.base}/users`); }
  addUser(v: User): Observable<User> { return this.http.post<User>(`${this.base}/users`, v); }
  cells(): Observable<Cell[]> { return this.http.get<Cell[]>(`${this.base}/cells`); }
  addCell(v: Cell): Observable<Cell> { return this.http.post<Cell>(`${this.base}/cells`, v); }
  vehicles(): Observable<Vehicle[]> { return this.http.get<Vehicle[]>(`${this.base}/vehicles`); }
  addVehicle(v: Vehicle): Observable<Vehicle> { return this.http.post<Vehicle>(`${this.base}/vehicles`, v); }
  activeSessions(): Observable<ParkingSession[]> { return this.http.get<ParkingSession[]>(`${this.base}/parking/active`); }
  parkingHistory(): Observable<ParkingSession[]> { return this.http.get<ParkingSession[]>(`${this.base}/parking/history`); }
  entry(v: {vehicle_id: number; cell_id?: number; entry_notes?: string}): Observable<ParkingSession> { return this.http.post<ParkingSession>(`${this.base}/parking/entry`, v); }
  exit(id: number, v: {exit_notes?: string} = {}): Observable<ParkingSession> { return this.http.post<ParkingSession>(`${this.base}/parking/${id}/exit`, v); }
  incidents(): Observable<Incident[]> { return this.http.get<Incident[]>(`${this.base}/incidents`); }
  addIncident(v: Incident): Observable<Incident> { return this.http.post<Incident>(`${this.base}/incidents`, v); }
  payments(): Observable<MonthlyPayment[]> { return this.http.get<MonthlyPayment[]>(`${this.base}/monthly-payments`); }
  paymentSummary(): Observable<PaymentSummary> { return this.http.get<PaymentSummary>(`${this.base}/monthly-payments/summary`); }
  addPayment(v: MonthlyPayment): Observable<MonthlyPayment> { return this.http.post<MonthlyPayment>(`${this.base}/monthly-payments`, v); }
  markPaid(id: number): Observable<MonthlyPayment> { return this.http.patch<MonthlyPayment>(`${this.base}/monthly-payments/${id}/pay`, {}); }
}
