export interface User { id?: number; full_name: string; document: string; phone?: string; email?: string; role?: string; active?: boolean; }
export interface Cell { id?: number; code: string; cell_type: string; is_active?: boolean; is_occupied?: boolean; }
export interface Vehicle { id?: number; plate: string; vehicle_type: string; brand?: string; color?: string; owner_id?: number | null; }
export interface ParkingSession { id: number; vehicle_id: number; cell_id: number; entry_at: string; exit_at?: string | null; entry_notes?: string; amount_cop?: number; duration_minutes?: number; receipt_number?: string | null; exit_notes?: string; }
export interface Incident { id?: number; vehicle_id: number; reported_by_user_id?: number | null; category: string; description: string; status?: string; created_at?: string; }
export interface MonthlyPayment { id?: number; user_id: number; vehicle_id: number; period_start: string; period_end: string; amount_cop: number; status?: string; reference?: string; paid_at?: string | null; }

export interface PaymentSummary {
  total_registros: number;
  total_facturado_cop: number;
  pendientes: number;
  valor_pendiente_cop: number;
  pagados: number;
  valor_recaudado_cop: number;
}
